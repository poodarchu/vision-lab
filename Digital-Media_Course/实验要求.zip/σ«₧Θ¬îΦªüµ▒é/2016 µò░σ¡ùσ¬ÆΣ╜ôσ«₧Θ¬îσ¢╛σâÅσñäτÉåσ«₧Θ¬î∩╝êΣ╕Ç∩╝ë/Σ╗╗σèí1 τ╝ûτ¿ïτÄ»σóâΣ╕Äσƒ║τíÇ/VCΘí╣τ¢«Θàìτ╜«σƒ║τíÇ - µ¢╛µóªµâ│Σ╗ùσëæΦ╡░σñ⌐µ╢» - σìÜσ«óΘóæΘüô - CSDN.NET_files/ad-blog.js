﻿var ad_type = 'js1020';
var ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);

 ad_type = 'ms1023_2';
 ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);

 ad_type = 'ms1026_3';
 ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);

 ad_type = 'ms1029_4';
 ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);
/*
 ad_type = 'ms846_5';
 ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);
*/